/**
 * 
 */
$(document).ready(function() {
	$('#usuarios').DataTable();
});
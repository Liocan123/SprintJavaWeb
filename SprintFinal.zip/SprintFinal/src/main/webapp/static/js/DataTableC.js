/**
 * 
 */
 
$(document).ready(function() {
	$('#capacitacion').DataTable();
});